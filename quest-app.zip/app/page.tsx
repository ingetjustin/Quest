"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trash2, RefreshCw, Check, Award, QrCode } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { quests, categories, categoryColors, type Quest } from "./quest_deck_full"
// Add this import at the top with your other imports
import { ShareButton } from "@/components/share-button"
import Link from "next/link"

// QuestTimer component for timed quests
function QuestTimer({ quest, onComplete }: { quest: Quest; onComplete: () => void }) {
  const [timeLeft, setTimeLeft] = useState(quest.timeLimit ? quest.timeLimit * 60 : 0)
  const [isRunning, setIsRunning] = useState(false)

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          setIsRunning(false)
          onComplete()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [isRunning, timeLeft, onComplete])

  const minutes = Math.floor(timeLeft / 60)
  const seconds = timeLeft % 60

  return (
    <div className="mt-2">
      <div className="flex items-center gap-2">
        <span className="font-mono">
          {minutes}:{seconds.toString().padStart(2, "0")}
        </span>
        <Button size="sm" variant={isRunning ? "destructive" : "outline"} onClick={() => setIsRunning(!isRunning)}>
          {isRunning ? "Pause" : "Start Timer"}
        </Button>
      </div>
    </div>
  )
}

export default function QuestDeckApp() {
  const [drawnQuests, setDrawnQuests] = useState<Quest[]>([])
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedDifficulty, setSelectedDifficulty] = useState("All")
  const [isDrawing, setIsDrawing] = useState(false)
  const [userPoints, setUserPoints] = useState(0)
  const [userLevel, setUserLevel] = useState(1)

  // Load saved quests from localStorage on initial render
  useEffect(() => {
    const savedQuests = localStorage.getItem("drawnQuests")
    const savedPoints = localStorage.getItem("userPoints")

    if (savedQuests) {
      setDrawnQuests(JSON.parse(savedQuests))
    }

    if (savedPoints) {
      const points = Number.parseInt(savedPoints)
      setUserPoints(points)
      setUserLevel(calculateLevel(points))
    }
  }, [])

  // Save quests to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("drawnQuests", JSON.stringify(drawnQuests))
    localStorage.setItem("userPoints", userPoints.toString())
  }, [drawnQuests, userPoints])

  const drawQuest = () => {
    setIsDrawing(true)

    // Filter out quests that have already been drawn
    const availableQuests = quests.filter((quest) => !drawnQuests.some((drawn) => drawn.id === quest.id))

    // Then filter by category and difficulty if needed
    const filtered = availableQuests.filter((quest) => {
      if (selectedCategory !== "All" && quest.category !== selectedCategory) return false
      if (selectedDifficulty !== "All" && quest.difficulty?.toLowerCase() !== selectedDifficulty.toLowerCase())
        return false
      return true
    })

    if (filtered.length === 0) {
      setTimeout(() => setIsDrawing(false), 500)
      return // No more quests available in this category/difficulty
    }

    const randomQuest = filtered[Math.floor(Math.random() * filtered.length)]

    // Add a small delay for animation effect
    setTimeout(() => {
      setDrawnQuests([...drawnQuests, { ...randomQuest, completed: false }])
      setIsDrawing(false)
    }, 500)
  }

  const removeQuest = (id: number) => {
    setDrawnQuests(drawnQuests.filter((quest) => quest.id !== id))
  }

  const calculateLevel = (points: number) => {
    return Math.floor(points / 100) + 1
  }

  const toggleComplete = (id: number) => {
    setDrawnQuests(
      drawnQuests.map((quest) => {
        if (quest.id === id) {
          const newCompleted = !quest.completed

          // Add points when completing a quest
          if (newCompleted) {
            let pointsEarned = 20 // Default points

            // Adjust points based on category and difficulty
            if (quest.category === "Legendary") pointsEarned = 50
            else if (quest.category === "Trickster") pointsEarned = 30

            if (quest.difficulty === "hard") pointsEarned *= 1.5
            else if (quest.difficulty === "easy") pointsEarned *= 0.75

            const newPoints = userPoints + Math.round(pointsEarned)
            setUserPoints(newPoints)
            setUserLevel(calculateLevel(newPoints))
          }

          return { ...quest, completed: newCompleted }
        }
        return quest
      }),
    )
  }

  const resetQuests = () => {
    if (confirm("Are you sure you want to reset all quests? Your points will be kept.")) {
      setDrawnQuests([])
    }
  }

  const completedCount = drawnQuests.filter((q) => q.completed).length
  const difficulties = ["All", "Easy", "Medium", "Hard"]

  return (
    <div className="p-6 max-w-xl mx-auto min-h-screen flex flex-col">
      <header className="mb-6 text-center">
        <h1 className="text-3xl font-bold mb-2">🛡️ The Order of Unnecessary Quests</h1>
        <p className="text-muted-foreground mb-4">Draw quests, complete them, and become a Guardian of the Realm!</p>

        {/* User stats */}
        <div className="flex justify-center items-center gap-4 mb-4">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            <Award className="h-4 w-4 mr-2" />
            Level {userLevel}
          </Badge>
          <Badge variant="outline" className="text-lg px-4 py-2">
            {userPoints} Points
          </Badge>
        </div>

        {/* Add the ShareButton component in the header section */}
        <div className="flex justify-center mt-2">
          <ShareButton />
          <Link href="/qr" className="ml-2">
            <Button variant="outline" size="sm">
              <QrCode className="h-4 w-4 mr-2" />
              QR Code
            </Button>
          </Link>
        </div>

        {drawnQuests.length > 0 && (
          <div className="flex justify-center items-center gap-2 mb-4">
            <Badge variant="outline" className="text-sm">
              {drawnQuests.length} Quest{drawnQuests.length !== 1 ? "s" : ""} Drawn
            </Badge>
            {completedCount > 0 && (
              <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                {completedCount} Completed
              </Badge>
            )}
          </div>
        )}
      </header>

      {/* Category filters */}
      <div className="flex flex-wrap gap-2 justify-center mb-4">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? "default" : "outline"}
            onClick={() => setSelectedCategory(cat)}
            className="transition-all duration-200"
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* Difficulty filters */}
      <div className="flex flex-wrap gap-2 justify-center mb-6">
        {difficulties.map((diff) => (
          <Button
            key={diff}
            variant={selectedDifficulty === diff ? "default" : "outline"}
            onClick={() => setSelectedDifficulty(diff)}
            className="transition-all duration-200"
          >
            {diff}
          </Button>
        ))}
      </div>

      {/* Action buttons */}
      <div className="text-center mb-8 flex justify-center gap-4">
        <Button onClick={drawQuest} disabled={isDrawing} className="relative" size="lg">
          {isDrawing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : null}
          Draw a Quest
        </Button>

        {drawnQuests.length > 0 && (
          <Button variant="outline" onClick={resetQuests} size="lg">
            <Trash2 className="mr-2 h-4 w-4" />
            Reset All
          </Button>
        )}
      </div>

      {/* Quest cards */}
      <div className="grid gap-4 flex-grow">
        <AnimatePresence>
          {drawnQuests.map((quest) => (
            <motion.div
              key={quest.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.3 }}
            >
              <Card className={`overflow-hidden ${quest.completed ? "border-green-500 dark:border-green-700" : ""}`}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <Badge className={`${categoryColors[quest.category] || ""}`}>{quest.category}</Badge>
                    {quest.difficulty && (
                      <Badge variant="outline">
                        {quest.difficulty.charAt(0).toUpperCase() + quest.difficulty.slice(1)}
                      </Badge>
                    )}
                    {quest.completed && (
                      <Badge
                        variant="outline"
                        className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                      >
                        <Check className="h-3 w-3 mr-1" /> Completed
                      </Badge>
                    )}
                  </div>
                  <p className={`text-lg ${quest.completed ? "line-through opacity-70" : ""}`}>{quest.text}</p>
                  {quest.timeLimit && <QuestTimer quest={quest} onComplete={() => toggleComplete(quest.id)} />}
                </CardContent>
                {/* Add the ShareButton component in the CardFooter of each quest card */}
                <CardFooter className="p-4 pt-0 flex justify-between">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => toggleComplete(quest.id)}>
                      {quest.completed ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Restart
                        </>
                      ) : (
                        <>
                          <Check className="h-4 w-4 mr-2" />
                          Complete
                        </>
                      )}
                    </Button>
                    <ShareButton quest={quest} />
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeQuest(quest.id)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-100"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>

        {drawnQuests.length === 0 && (
          <div className="text-center p-12 border border-dashed rounded-lg flex flex-col items-center justify-center text-muted-foreground">
            <Award className="h-12 w-12 mb-4 opacity-50" />
            <p>No quests drawn yet. Click "Draw a Quest" to begin your adventure!</p>
          </div>
        )}
      </div>
    </div>
  )
}
