// Define the Quest type
export type Quest = {
  id: number
  text: string
  category: "Scavenger" | "Silly" | "Helpful" | "Trickster" | "Legendary"
  difficulty?: "easy" | "medium" | "hard"
  timeLimit?: number // in minutes
  completed?: boolean
}

// Export the categories as a constant
export const categories = ["All", "Scavenger", "Silly", "Helpful", "Trickster", "Legendary"]
export const difficulties = ["All", "Easy", "Medium", "Hard"]

// Export the category colors
export const categoryColors: Record<string, string> = {
  Scavenger: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300",
  Silly: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300",
  Helpful: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
  Trickster: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
  Legendary: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
}

// Export the quests array
export const quests: Quest[] = [
  // Scavenger Quests
  { id: 1, text: "Find a blue button and trade it with a stranger.", category: "Scavenger", difficulty: "easy" },
  { id: 2, text: "Locate something that is exactly 5 inches long.", category: "Scavenger", difficulty: "medium" },
  {
    id: 3,
    text: "Find an object that starts with the first letter of your name.",
    category: "Scavenger",
    difficulty: "easy",
  },
  {
    id: 4,
    text: "Discover something that makes an interesting sound and share it.",
    category: "Scavenger",
    difficulty: "medium",
  },
  { id: 5, text: "Find something older than you are.", category: "Scavenger", difficulty: "medium" },

  // Silly Quests
  { id: 6, text: "Speak only in pirate voice for 5 minutes.", category: "Silly", difficulty: "medium", timeLimit: 5 },
  { id: 7, text: "Make up a 30-second song about your day and perform it.", category: "Silly", difficulty: "medium" },
  { id: 8, text: "Walk backwards for the next 100 steps.", category: "Silly", difficulty: "easy" },
  { id: 9, text: "Tell a joke to the next person you see.", category: "Silly", difficulty: "easy" },
  {
    id: 10,
    text: "Do your best impression of a famous movie character for 2 minutes.",
    category: "Silly",
    difficulty: "medium",
    timeLimit: 2,
  },

  // Helpful Quests
  { id: 11, text: "Compliment someone's energy, not their appearance.", category: "Helpful", difficulty: "easy" },
  { id: 12, text: "Leave an encouraging note in a public place.", category: "Helpful", difficulty: "medium" },
  { id: 13, text: "Help someone carry something heavy.", category: "Helpful", difficulty: "medium" },
  { id: 14, text: "Give directions to someone who looks lost.", category: "Helpful", difficulty: "easy" },
  { id: 15, text: "Clean up trash you find in a public space.", category: "Helpful", difficulty: "medium" },

  // Trickster Quests
  { id: 16, text: "Draw a smiley face on a coin and leave it heads-up.", category: "Trickster", difficulty: "easy" },
  {
    id: 17,
    text: "Leave a small treasure with a riddle for someone to find.",
    category: "Trickster",
    difficulty: "hard",
  },
  {
    id: 18,
    text: "Convince someone that you're a tourist from another country.",
    category: "Trickster",
    difficulty: "hard",
  },
  {
    id: 19,
    text: "Create a fake 'fact' and casually mention it in conversation.",
    category: "Trickster",
    difficulty: "medium",
  },
  {
    id: 20,
    text: "Pretend to be on an important phone call in a public place.",
    category: "Trickster",
    difficulty: "medium",
  },

  // Legendary Quests
  {
    id: 21,
    text: "Recruit a party of strangers to complete a quest together.",
    category: "Legendary",
    difficulty: "hard",
  },
  {
    id: 22,
    text: "Start a spontaneous dance party with at least 3 other people.",
    category: "Legendary",
    difficulty: "hard",
  },
  {
    id: 23,
    text: "Create a small act of public art that will make people smile.",
    category: "Legendary",
    difficulty: "hard",
  },
  {
    id: 24,
    text: "Organize a mini-adventure for a friend without telling them in advance.",
    category: "Legendary",
    difficulty: "hard",
  },
  {
    id: 25,
    text: "At the end of a full quest day, knight yourself publicly — and accept your role as Guardian of the Realm.",
    category: "Legendary",
    difficulty: "hard",
  },

  // Add more quests as needed...
]
