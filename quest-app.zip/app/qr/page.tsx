import QRGenerator from "@/components/qr-generator"

export default function QRPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-8">QR Code for The Order of Unnecessary Quests</h1>
      <QRGenerator />

      <div className="mt-8 text-center text-sm text-muted-foreground">
        <p>Use this QR code to share your app with friends!</p>
        <p className="mt-2">Print it out or share it digitally.</p>
      </div>
    </div>
  )
}
