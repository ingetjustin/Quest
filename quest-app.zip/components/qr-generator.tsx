"use client"

import { useState, useRef } from "react"
import QRCode from "react-qr-code"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Share2 } from "lucide-react"

export default function QRGenerator() {
  const [url, setUrl] = useState("")
  const [generatedUrl, setGeneratedUrl] = useState("")
  const qrRef = useRef<HTMLDivElement>(null)

  // Try to get the current URL when component mounts
  useState(() => {
    if (typeof window !== "undefined") {
      setUrl(window.location.href)
    }
  })

  const generateQR = () => {
    setGeneratedUrl(url)
  }

  const downloadQRCode = () => {
    if (!qrRef.current) return

    const canvas = document.createElement("canvas")
    const svg = qrRef.current.querySelector("svg")

    if (!svg) return

    const svgData = new XMLSerializer().serializeToString(svg)
    const blob = new Blob([svgData], { type: "image/svg+xml" })
    const url = URL.createObjectURL(blob)

    const img = new Image()
    img.onload = () => {
      canvas.width = img.width
      canvas.height = img.height
      const ctx = canvas.getContext("2d")
      if (!ctx) return

      // Fill with white background
      ctx.fillStyle = "white"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      ctx.drawImage(img, 0, 0)

      const pngUrl = canvas.toDataURL("image/png")
      const downloadLink = document.createElement("a")
      downloadLink.href = pngUrl
      downloadLink.download = "quest-app-qr.png"
      document.body.appendChild(downloadLink)
      downloadLink.click()
      document.body.removeChild(downloadLink)
      URL.revokeObjectURL(url)
    }
    img.src = url
  }

  const shareQRCode = async () => {
    if (!qrRef.current || !generatedUrl) return

    try {
      if (navigator.share) {
        await navigator.share({
          title: "The Order of Unnecessary Quests",
          text: "Check out this quest app!",
          url: generatedUrl,
        })
      } else {
        await navigator.clipboard.writeText(generatedUrl)
        alert("URL copied to clipboard!")
      }
    } catch (error) {
      console.error("Error sharing:", error)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">QR Code Generator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="url" className="text-sm font-medium">
            Your App URL
          </label>
          <div className="flex space-x-2">
            <Input
              id="url"
              placeholder="https://your-app.vercel.app"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
            <Button onClick={generateQR}>Generate</Button>
          </div>
        </div>

        {generatedUrl && (
          <div className="flex justify-center p-4 bg-white rounded-lg" ref={qrRef}>
            <QRCode value={generatedUrl} size={200} />
          </div>
        )}
      </CardContent>

      {generatedUrl && (
        <CardFooter className="flex justify-center space-x-2">
          <Button variant="outline" onClick={downloadQRCode}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
          <Button variant="outline" onClick={shareQRCode}>
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}
