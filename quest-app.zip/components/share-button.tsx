"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Share, Check, Copy, Twitter, Facebook } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import type { Quest } from "@/app/quest_deck_full"

interface ShareButtonProps {
  quest?: Quest
  shareUrl?: string
  shareTitle?: string
}

export function ShareButton({
  quest,
  shareUrl = typeof window !== "undefined" ? window.location.href : "",
  shareTitle = "Check out this quest from The Order of Unnecessary Quests!",
}: ShareButtonProps) {
  const [copied, setCopied] = useState(false)

  const title = quest ? `Quest: "${quest.text}" from The Order of Unnecessary Quests` : shareTitle

  const url = shareUrl

  const copyToClipboard = () => {
    navigator.clipboard.writeText(quest ? `${title} - ${url}` : url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const shareOnTwitter = () => {
    const text = encodeURIComponent(title)
    const shareUrl = encodeURIComponent(url)
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${shareUrl}`, "_blank")
  }

  const shareOnFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank")
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm">
          <Share className="h-4 w-4 mr-2" />
          Share
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="space-y-2">
          <h3 className="font-medium">Share this {quest ? "quest" : "app"}</h3>
          <p className="text-sm text-muted-foreground">
            {quest ? quest.text : "Share The Order of Unnecessary Quests with your friends!"}
          </p>
          <div className="flex gap-2 mt-4">
            <Button onClick={copyToClipboard} variant="outline" className="flex-1">
              {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
              {copied ? "Copied!" : "Copy Link"}
            </Button>
            <Button onClick={shareOnTwitter} variant="outline" size="icon">
              <Twitter className="h-4 w-4" />
            </Button>
            <Button onClick={shareOnFacebook} variant="outline" size="icon">
              <Facebook className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}
